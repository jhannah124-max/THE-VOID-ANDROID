plugins { id("com.android.application") }
android {
    namespace = "com.thevoid.ambient"
    compileSdk = 35
    defaultConfig { applicationId = "com.thevoid.ambient"; minSdk = 26; targetSdk = 28; versionCode = 11; versionName = "1.1" }
    buildTypes { release { isMinifyEnabled = false } }
    compileOptions { sourceCompatibility = JavaVersion.VERSION_17; targetCompatibility = JavaVersion.VERSION_17 }
}
