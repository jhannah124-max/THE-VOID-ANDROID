# THE VOID v1.1 — Android Landscape Edition

Native Android WebView shell around the existing THE VOID v1.0 psychedelic synthesis prototype, labeled v1.1. Locks phone activity to landscape and hides system bars in immersive mode. Offline HTML/Web Audio assets are bundled.

## Build an APK
1. Open this folder as a project in Android Studio (recent version with Android SDK 35 and JDK 17).
2. Let Gradle sync and install any prompted SDK components.
3. Select **Build > Build Bundle(s) / APK(s) > Build APK(s)**.
4. Find the debug APK at `app/build/outputs/apk/debug/app-debug.apk` and transfer it to your Android phone to install.

## Notes / limitations
- This source project is **not a compiled APK**. No Android SDK/Gradle tooling was available in the generation environment.
- This version uses Android WebView and the existing Web Audio engine, not a native low-latency Oboe audio engine.
- Audio and file import depend on the installed Android System WebView version.
- Local file download/export (blob URLs) may not work in WebView yet; Android Storage Access Framework export integration is a future task.
- No background playback service; app keeps screen awake while open. Immersive navigation bars can reappear on gesture.
- Screen orientation may be overridden by some large-screen Android device policies.
- The existing HTML UI is largely preserved; test controls on your actual landscape phone before considering it polished.
- Target SDK 28 is used as a compatibility prototype. Update target SDK, permissions, file exports, and lifecycle before Play Store distribution.
